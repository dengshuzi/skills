import {
  createAgentSession,
  SessionManager,
} from "@mariozechner/pi-coding-agent";
import type { AgentSession } from "@mariozechner/pi-coding-agent";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

export const DEMO_SESSION_COOKIE = "pi-demo-session-id";
export const DEMO_SESSION_FILE_COOKIE = "pi-demo-session-file";

let currentSession: AgentSession | null = null;
const currentRunning = new Map<string, Promise<unknown>>();
const sessionRuntimeStates = new Map<string, DemoRuntimeState>();

interface DemoRuntimeState {
  isRunning: boolean;
  lastReply: string;
  lastError: string | null;
  updatedAt: string | null;
}

type SessionManagerWithHelpers = typeof SessionManager & {
  open(sessionFile: string): unknown;
  list(cwd: string): Promise<Array<{ id: string; path: string }>>;
};

function getSessionHelpers(): SessionManagerWithHelpers {
  return SessionManager as SessionManagerWithHelpers;
}

function getSessionFile(session: AgentSession): string | null {
  const sessionWithFile = session as AgentSession & { sessionFile?: string };
  return sessionWithFile.sessionFile ?? null;
}

function createDefaultRuntimeState(): DemoRuntimeState {
  return {
    isRunning: false,
    lastReply: "",
    lastError: null,
    updatedAt: null,
  };
}

function getRuntimeState(sessionId: string): DemoRuntimeState {
  return sessionRuntimeStates.get(sessionId) ?? createDefaultRuntimeState();
}

function updateRuntimeState(
  sessionId: string,
  patch: Partial<DemoRuntimeState>,
): DemoRuntimeState {
  const nextState: DemoRuntimeState = {
    ...getRuntimeState(sessionId),
    ...patch,
    updatedAt: new Date().toISOString(),
  };

  sessionRuntimeStates.set(sessionId, nextState);
  return nextState;
}

/** Create a new demo session and replace the current one. */
export async function newDemoSession(): Promise<AgentSession> {
  const { session } = await createAgentSession({
    cwd: process.cwd(),
    sessionManager: SessionManager.create(process.cwd()),
  });
  currentSession = session;
  updateRuntimeState(session.sessionId, createDefaultRuntimeState());
  return session;
}

async function openDemoSession(sessionId: string): Promise<AgentSession | null> {
  if (currentSession?.sessionId === sessionId) {
    return currentSession;
  }

  const sessionHelpers = getSessionHelpers();
  const sessions = await sessionHelpers.list(process.cwd());
  const matchedSession = sessions.find((session) => session.id === sessionId);

  if (!matchedSession) {
    return null;
  }

  const { session } = await createAgentSession({
    cwd: process.cwd(),
    sessionManager: sessionHelpers.open(matchedSession.path) as SessionManager,
  });

  currentSession = session;
  updateRuntimeState(session.sessionId, getRuntimeState(session.sessionId));
  return session;
}

async function openDemoSessionFile(
  sessionFile: string,
): Promise<AgentSession> {
  const sessionHelpers = getSessionHelpers();
  const { session } = await createAgentSession({
    cwd: process.cwd(),
    sessionManager: sessionHelpers.open(sessionFile) as SessionManager,
  });

  currentSession = session;
  updateRuntimeState(session.sessionId, getRuntimeState(session.sessionId));
  return session;
}

/** Get the current session, creating one if none exists. */
export async function getDemoSession(
  sessionId?: string | null,
  sessionFile?: string | null,
): Promise<AgentSession> {
  if (sessionFile) {
    return openDemoSessionFile(sessionFile);
  }

  if (sessionId) {
    const session = await openDemoSession(sessionId);

    if (session) {
      return session;
    }
  }

  if (currentSession) {
    return currentSession;
  }

  return newDemoSession();
}

/** Extract the last assistant text from the session state. */
function extractLastAssistantText(session: AgentSession): string {
  const messages = session.state.messages;
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (msg.role === "assistant") {
      const textParts: string[] = [];
      for (const block of msg.content) {
        if (block.type === "text") {
          textParts.push(block.text);
        }
      }
      const text = textParts.join("");
      if (text) return text;
      // Fallback: surface the error message when content is empty
      if ("errorMessage" in msg && typeof (msg as any).errorMessage === "string") {
        return `[API Error] ${(msg as any).errorMessage}`;
      }
      return "";
    }
  }
  return "";
}

/** Run a task exclusively – reject if another prompt is already running. */
async function runExclusive<T>(
  sessionId: string,
  task: () => Promise<T>,
): Promise<T> {
  if (currentRunning.has(sessionId)) {
    throw new Error("当前 session 正在处理中，请等待完成后再试");
  }

  const promise = task();
  currentRunning.set(sessionId, promise);
  try {
    return (await promise) as T;
  } finally {
    currentRunning.delete(sessionId);
  }
}

/** Send a plain message to the current session and return the reply. */
export async function sendDemoMessage(message: string): Promise<{
  sessionId: string;
  reply: string;
}> {
  const session = await getDemoSession();
  return runExclusive(session.sessionId, async () => {
    await session.prompt(message);
    return {
      sessionId: session.sessionId,
      reply: extractLastAssistantText(session),
    };
  });
}

/** Run the `/tilldown` command on the current session. */
export async function runTilldown(): Promise<{
  sessionId: string;
  reply: string;
}> {
  const session = await getDemoSession();
  return runExclusive(session.sessionId, async () => {
    await session.prompt("/tilldown");
    return {
      sessionId: session.sessionId,
      reply: extractLastAssistantText(session),
    };
  });
}

/** Read the task file for the current session. */
export function readDemoTasks(): {
  sessionId: string | null;
  tasks: unknown;
} {
  if (!currentSession) {
    return { sessionId: null, tasks: null };
  }
  const sessionId = currentSession.sessionId;
  const file = join(
    process.cwd(),
    ".pi",
    "tilldown",
    `tasks.${sessionId}.json`,
  );
  if (!existsSync(file)) {
    return { sessionId, tasks: null };
  }
  try {
    const raw = readFileSync(file, "utf8");
    const tasks = JSON.parse(raw);
    return { sessionId, tasks };
  } catch {
    throw new Error("任务文件 JSON 格式错误，无法解析");
  }
}

/** Get the current session ID (null if no session). */
export function getCurrentSessionId(): string | null {
  return currentSession?.sessionId ?? null;
}

export async function createDemoSession(): Promise<{
  sessionId: string;
  sessionFile: string | null;
}> {
  const session = await newDemoSession();

  return {
    sessionId: session.sessionId,
    sessionFile: getSessionFile(session),
  };
}

export async function sendDemoMessageForSession(
  message: string,
  sessionId?: string | null,
  sessionFile?: string | null,
): Promise<{
  sessionId: string;
  sessionFile: string | null;
  reply: string;
}> {
  const session = await getDemoSession(sessionId, sessionFile);

  const result = await runExclusive(session.sessionId, async () => {
    await session.prompt(message);
    const reply = extractLastAssistantText(session);
    updateRuntimeState(session.sessionId, {
      isRunning: false,
      lastError: null,
      lastReply: reply,
    });
    return {
      sessionId: session.sessionId,
      sessionFile: getSessionFile(session),
      reply,
    };
  });

  currentSession = session;
  return result;
}

export async function runTilldownForSession(
  sessionId?: string | null,
  sessionFile?: string | null,
): Promise<{
  sessionId: string;
  sessionFile: string | null;
  reply: string;
}> {
  const session = await getDemoSession(sessionId, sessionFile);

  const result = await runExclusive(session.sessionId, async () => {
    await session.prompt("/tilldown");
    return {
      sessionId: session.sessionId,
      sessionFile: getSessionFile(session),
      reply: extractLastAssistantText(session),
    };
  });

  currentSession = session;
  return result;
}

export async function startTilldownForSession(
  sessionId?: string | null,
  sessionFile?: string | null,
): Promise<{
  sessionId: string;
  sessionFile: string | null;
  started: boolean;
  alreadyRunning: boolean;
  reply: string;
}> {
  const session = await getDemoSession(sessionId, sessionFile);
  const resolvedSessionFile = getSessionFile(session);

  if (currentRunning.has(session.sessionId)) {
    return {
      sessionId: session.sessionId,
      sessionFile: resolvedSessionFile,
      started: false,
      alreadyRunning: true,
      reply: "当前 tilldown 正在运行，请稍候。",
    };
  }

  updateRuntimeState(session.sessionId, {
    isRunning: true,
    lastError: null,
    lastReply: "Tilldown 已启动，任务结果会陆续刷新。",
  });

  const promise = (async () => {
    try {
      await session.prompt("/tilldown");
      updateRuntimeState(session.sessionId, {
        isRunning: false,
        lastError: null,
        lastReply: extractLastAssistantText(session),
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "执行 /tilldown 失败";
      updateRuntimeState(session.sessionId, {
        isRunning: false,
        lastError: message,
      });
    } finally {
      currentRunning.delete(session.sessionId);
    }
  })();

  currentRunning.set(session.sessionId, promise);
  currentSession = session;

  promise.catch(() => undefined);

  return {
    sessionId: session.sessionId,
    sessionFile: resolvedSessionFile,
    started: true,
    alreadyRunning: false,
    reply: "Tilldown 已启动，任务结果会陆续刷新。",
  };
}

export function readDemoTasksForSession(sessionId?: string | null): {
  sessionId: string | null;
  tasks: unknown;
  runtime: DemoRuntimeState | null;
} {
  if (!sessionId) {
    return { sessionId: null, tasks: null, runtime: null };
  }

  const file = join(
    process.cwd(),
    ".pi",
    "tilldown",
    `tasks.${sessionId}.json`,
  );

  if (!existsSync(file)) {
    return { sessionId, tasks: null, runtime: getRuntimeState(sessionId) };
  }

  try {
    const raw = readFileSync(file, "utf8");
    const tasks = JSON.parse(raw);
    return { sessionId, tasks, runtime: getRuntimeState(sessionId) };
  } catch {
    throw new Error("任务文件 JSON 格式错误，无法解析");
  }
}
