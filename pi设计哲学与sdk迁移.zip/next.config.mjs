/** @type {import('next').NextConfig} */
const nextConfig = {
  allowedDevOrigins: ["127.0.0.1"],
  serverExternalPackages: [
    "@mariozechner/pi-ai",
    "@mariozechner/pi-coding-agent",
  ],
};

export default nextConfig;
