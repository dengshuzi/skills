export const runtime = "nodejs";

import { cookies } from "next/headers";

import {
  DEMO_SESSION_COOKIE,
  DEMO_SESSION_FILE_COOKIE,
  startTilldownForSession,
} from "../../../../src/lib/pi-demo";

export async function POST() {
  try {
    const cookieStore = await cookies();
    const result = await startTilldownForSession(
      cookieStore.get(DEMO_SESSION_COOKIE)?.value,
      cookieStore.get(DEMO_SESSION_FILE_COOKIE)?.value,
    );

    cookieStore.set(DEMO_SESSION_COOKIE, result.sessionId, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
    });

    if (result.sessionFile) {
      cookieStore.set(DEMO_SESSION_FILE_COOKIE, result.sessionFile, {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
      });
    }

    return Response.json({ ok: true, data: result });
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : "执行 /tilldown 失败";
    const safeMessage = message.replace(/\/[^\s"']+/g, "[path]");
    return Response.json({ ok: false, error: safeMessage }, { status: 500 });
  }
}
