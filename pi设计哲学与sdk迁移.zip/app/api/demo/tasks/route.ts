export const runtime = "nodejs";

import { cookies } from "next/headers";

import {
  DEMO_SESSION_COOKIE,
  readDemoTasksForSession,
} from "../../../../src/lib/pi-demo";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const result = readDemoTasksForSession(
      cookieStore.get(DEMO_SESSION_COOKIE)?.value,
    );

    return Response.json({ ok: true, data: result });
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : "读取任务文件失败";
    // Strip any absolute filesystem paths from error messages
    const safeMessage = message.replace(/\/[^\s"']+/g, "[path]");
    return Response.json({ ok: false, error: safeMessage }, { status: 500 });
  }
}
