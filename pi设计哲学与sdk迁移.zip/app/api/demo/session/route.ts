export const runtime = "nodejs";

import { cookies } from "next/headers";

import {
  createDemoSession,
  DEMO_SESSION_COOKIE,
  DEMO_SESSION_FILE_COOKIE,
} from "../../../../src/lib/pi-demo";

export async function POST() {
  try {
    const session = await createDemoSession();
    const cookieStore = await cookies();

    cookieStore.set(DEMO_SESSION_COOKIE, session.sessionId, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
    });

    if (session.sessionFile) {
      cookieStore.set(DEMO_SESSION_FILE_COOKIE, session.sessionFile, {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
      });
    }

    return Response.json({
      ok: true,
      data: { sessionId: session.sessionId },
    });
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : "创建 session 失败";
    // Strip any absolute filesystem paths from error messages
    const safeMessage = message.replace(/\/[^\s"']+/g, "[path]");
    return Response.json({ ok: false, error: safeMessage }, { status: 500 });
  }
}
