"use client";

import { useEffect, useMemo, useState } from "react";

interface DemoRuntimeState {
  isRunning: boolean;
  lastReply: string;
  lastError: string | null;
  updatedAt: string | null;
}

interface TaskItem {
  id: string;
  description: string;
  status: string;
  result: string | null;
  lastError: string | null;
}

interface TaskStore {
  runnerStatus?: string;
  currentTaskId?: string | null;
  tasks?: TaskItem[];
}

export default function Page() {
  const [sessionId, setSessionId] = useState<string>("");
  const [message, setMessage] = useState<string>("");
  const [reply, setReply] = useState<string>("");
  const [taskStore, setTaskStore] = useState<TaskStore | null>(null);
  const [tasksText, setTasksText] = useState<string>("No task file yet");
  const [runtimeState, setRuntimeState] = useState<DemoRuntimeState | null>(null);
  const [error, setError] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [pollingTilldown, setPollingTilldown] = useState<boolean>(false);

  useEffect(() => {
    createSession();
  }, []);

  useEffect(() => {
    if (!pollingTilldown) {
      return;
    }

    const timer = window.setInterval(() => {
      void loadTasksIntoState({ silent: true });
    }, 1500);

    return () => {
      window.clearInterval(timer);
    };
  }, [pollingTilldown]);

  const taskResults = useMemo(() => {
    return (taskStore?.tasks ?? []).filter((task) => task.result || task.lastError);
  }, [taskStore]);

  async function loadTasksIntoState(options?: { silent?: boolean }) {
    const res = await fetch("/api/demo/tasks");
    const data = await res.json();

    if (!data.ok) {
      throw new Error(data.error || "Failed to refresh tasks");
    }

    const nextTaskStore = (data.data.tasks ?? null) as TaskStore | null;
    const nextRuntimeState = (data.data.runtime ?? null) as DemoRuntimeState | null;

    setTaskStore(nextTaskStore);
    setRuntimeState(nextRuntimeState);

    if (nextRuntimeState?.lastReply) {
      setReply(nextRuntimeState.lastReply);
    }

    if (data.data.tasks) {
      setTasksText(JSON.stringify(data.data.tasks, null, 2));
    } else {
      setTasksText("No task file yet");
    }

    if (data.data.sessionId) {
      setSessionId(data.data.sessionId);
    }

    const shouldContinuePolling =
      nextRuntimeState?.isRunning === true ||
      nextTaskStore?.runnerStatus === "running" ||
      nextTaskStore?.runnerStatus === "stopping";

    setPollingTilldown(shouldContinuePolling);

    if (nextRuntimeState?.lastError) {
      setError(nextRuntimeState.lastError);
    } else if (!options?.silent) {
      setError("");
    }
  }

  async function createSession() {
    setLoading(true);
    setError("");
    setReply("");
    setTaskStore(null);
    setRuntimeState(null);
    setPollingTilldown(false);
    setTasksText("No task file yet");
    try {
      const res = await fetch("/api/demo/session", { method: "POST" });
      const data = await res.json();
      if (data.ok) {
        setSessionId(data.data.sessionId);
        await loadTasksIntoState();
      } else {
        setError(data.error || "Failed to create session");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Network error");
    } finally {
      setLoading(false);
    }
  }

  async function sendMessage() {
    if (!message.trim()) return;
    setLoading(true);
    setError("");
    setPollingTilldown(false);
    try {
      const res = await fetch("/api/demo/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      const data = await res.json();
      if (data.ok) {
        setReply(data.data.reply);
        setSessionId(data.data.sessionId);
        await loadTasksIntoState();
      } else {
        setError(data.error || "Failed to send message");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Network error");
    } finally {
      setLoading(false);
    }
  }

  async function runTilldown() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/demo/tilldown", { method: "POST" });
      const data = await res.json();
      if (data.ok) {
        setReply(data.data.reply);
        setSessionId(data.data.sessionId);
        setPollingTilldown(true);
        await loadTasksIntoState({ silent: true });
      } else {
        setError(data.error || "Failed to run /tilldown");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Network error");
    } finally {
      setLoading(false);
    }
  }

  async function refreshTasks() {
    setLoading(true);
    setError("");
    try {
      await loadTasksIntoState();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Network error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ maxWidth: 720, margin: "0 auto", padding: 24, fontFamily: "sans-serif" }}>
      <h1>Pi SDK Extension Migration POC</h1>
      <p>
        <strong>Session ID:</strong> {sessionId || "(none)"}
      </p>
      <p>
        <strong>Runner:</strong>{" "}
        {runtimeState?.isRunning
          ? "Running..."
          : taskStore?.runnerStatus ?? "idle"}
      </p>
      <button onClick={createSession} disabled={loading}>
        New Session
      </button>

      <hr style={{ margin: "16px 0" }} />

      <div>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          style={{ width: "60%", padding: 6, marginRight: 8 }}
          disabled={loading}
        />
        <button onClick={sendMessage} disabled={loading}>
          Send Message
        </button>
        <button onClick={runTilldown} disabled={loading} style={{ marginLeft: 8 }}>
          Run /tilldown
        </button>
        <button onClick={refreshTasks} disabled={loading} style={{ marginLeft: 8 }}>
          Refresh Tasks
        </button>
      </div>

      <hr style={{ margin: "16px 0" }} />

      <section>
        <h3>Assistant Reply</h3>
        <pre style={{ background: "#f5f5f5", padding: 12, whiteSpace: "pre-wrap" }}>
          {runtimeState?.isRunning
            ? `${reply || "(starting...)"}\n\nPolling task progress...`
            : reply || runtimeState?.lastReply || "(no reply yet)"}
        </pre>
      </section>

      <section>
        <h3>Task Results (Full Output)</h3>
        <div style={{ background: "#f5f5f5", padding: 12 }}>
          {taskResults.length === 0 ? (
            <p style={{ margin: 0 }}>(no task results yet)</p>
          ) : (
            taskResults.map((task) => (
              <div key={task.id} style={{ marginBottom: 12 }}>
                <strong>{task.id}</strong> [{task.status}] - {task.description}
                <pre style={{ margin: "8px 0 0", whiteSpace: "pre-wrap" }}>
                  {task.result || task.lastError}
                </pre>
              </div>
            ))
          )}
        </div>
      </section>

      <section>
        <h3>Task JSON</h3>
        <pre style={{ background: "#f5f5f5", padding: 12, whiteSpace: "pre-wrap" }}>
          {tasksText}
        </pre>
      </section>

      {error && (
        <section>
          <p style={{ color: "red" }}>{error}</p>
        </section>
      )}
    </main>
  );
}
