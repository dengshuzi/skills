# Next.js 多用户 Pi 会话与 tilldown 任务清单系统实施开发文档

## 1. 文档目的

本文档用于指导初级开发人员基于 Next.js 开发一个多用户网页系统。  
系统需要接入 Pi Coding Agent SDK，并复用当前项目中已经开发完成的 `.pi/extensions/tilldown` 扩展插件。

开发人员阅读本文档后，应能够直接开始开发，不需要再向需求方补问核心产品需求。

本期目标是做一个可测试版本：

- 使用 Next.js 开发网页应用
- 写死两个测试账号用于登录
- 每个账号登录后只能看到自己的会话
- 每个账号支持多个 Pi session
- 页面左侧显示会话列表
- 页面中间显示当前会话的 AI 对话窗口
- 页面右侧显示当前会话的 tilldown 任务列表
- 支持创建新会话
- 支持切换会话
- 支持发送消息给 AI
- 支持通过按钮启动 `/tilldown`
- 右侧任务列表能动态刷新

## 2. 重要前提

### 2.1 当前已有插件

当前项目中已经存在 tilldown 插件：

```text
.pi/extensions/tilldown/
```

该插件已经提供：

- 任务清单文件化存储
- 按 sessionId 隔离任务文件
- todo 增删改查工具
- `/tilldown` 命令
- `/tilldown-status` 命令
- `/tilldown-stop` 命令
- `agent_end` 后自动续跑
- 失败后继续执行后续任务
- 任务未正确收尾时自动重试，超过次数后标记失败

本期 Next.js 开发优先复用该插件，不要求重写插件。

### 2.2 多用户由 Next.js 应用层负责

Pi SDK 本身支持多 session，但不内置多用户、租户、权限、登录体系。  
因此本系统的多用户隔离必须由 Next.js 应用层实现。

要求：

- 用户登录身份由 Next.js 维护
- 用户只能访问自己的 session
- API 层必须校验当前登录用户
- 不允许前端直接传任意 sessionId 就访问
- sessionId 必须在服务端校验归属

### 2.3 Pi SDK 必须运行在服务端 Node.js

Pi SDK 和当前 tilldown 插件都依赖 Node.js 能力。  
尤其当前插件使用了本地文件系统，因此不能在浏览器端运行。

要求：

- Pi SDK 只能在 Next.js 服务端代码中使用
- Route Handler / Server Action 必须使用 Node.js runtime
- 不允许在 Client Component 中直接 import Pi SDK
- 不允许在浏览器端直接访问 `.pi` 文件

## 3. 推荐技术栈

基础技术栈：

- Next.js App Router
- TypeScript
- React Server Components + Client Components
- Route Handlers
- Node.js runtime

本期为了快速验证，不强制接数据库。  
可以先使用服务端本地 JSON 文件保存用户会话映射。

建议后续生产化时替换为：

- PostgreSQL / SQLite / Supabase / Prisma
- Redis 或数据库锁
- 正式鉴权系统

## 4. 本期明确不做的内容

以下内容不属于本期范围：

- 不做真实注册系统
- 不做第三方 OAuth 登录
- 不做复杂权限管理
- 不做计费系统
- 不做多租户后台管理
- 不做生产级多实例部署
- 不做任务拖拽排序
- 不做复杂任务依赖图
- 不重写 `.pi/extensions/tilldown` 插件

## 5. 测试账号要求

本期写死两个账号即可。

建议账号如下：

```text
账号一：
username: user1
password: 123456

账号二：
username: user2
password: 123456
```

账号信息必须只放在服务端代码中，不能放到前端可直接访问的地方。

登录成功后，需要在浏览器中保存登录态。

本期可以使用：

- HTTP-only Cookie
- 简单 session token

不要求接正式认证库，但不能把密码明文暴露给前端。

## 6. 页面整体布局

登录成功后进入主页面。  
主页面是三栏布局：

```text
┌────────────────┬──────────────────────────────┬──────────────────────┐
│ 左侧会话列表    │ 中间 AI 对话窗口              │ 右侧任务列表          │
│                │                              │                      │
│ 新建会话按钮    │ 消息记录                      │ pending              │
│ 会话 A          │ AI 回复                       │ in_progress          │
│ 会话 B          │ 用户输入框                    │ done                 │
│ 会话 C          │ 发送按钮                      │ failed               │
│                │ tilldown 启动按钮             │ 刷新按钮             │
└────────────────┴──────────────────────────────┴──────────────────────┘
```

### 6.1 左侧栏

左侧栏功能：

- 显示当前用户的所有会话
- 支持点击切换当前会话
- 支持创建新会话
- 显示当前选中的会话

会话列表只显示当前登录用户自己的 session。

### 6.2 中间栏

中间栏功能：

- 显示当前会话的历史消息
- 用户可以输入自然语言
- 用户可以发送消息给 AI
- AI 回复显示在消息区
- 支持流式输出更好，但本期不强制
- 支持一个“开始 tilldown”按钮

“开始 tilldown”按钮的行为：

- 后端向当前 Pi session 发送 `/tilldown`
- 启动当前 session 的任务自动执行流程

### 6.3 右侧栏

右侧栏功能：

- 显示当前会话的任务清单
- 显示任务状态
- 显示任务描述
- 显示当前任务统计
- 支持手动刷新
- 支持自动刷新

本期右侧任务列表可以先只读展示。  
如果开发时间允许，可以增加新增、编辑、删除任务按钮，但不是硬性要求。

## 7. 用户与 session 关系设计

### 7.1 数据关系

系统关系如下：

```text
User
  └── Session[]
        └── Tilldown Task File
```

一个用户可以有多个 session。  
一个 session 对应一个 Pi AgentSession。  
一个 session 对应一个 tilldown 任务文件。

### 7.2 用户隔离原则

必须遵守：

- `user1` 不能看到 `user2` 的 session
- `user1` 不能访问 `user2` 的任务列表
- `user1` 不能向 `user2` 的 session 发送消息
- 所有 API 必须从登录态中解析当前用户
- 所有 API 必须校验 session 属于当前用户

### 7.3 session 映射数据

本期可用 JSON 文件保存 session 映射。

建议保存位置：

```text
.next-pi-data/users.json
```

示例结构：

```json
{
  "user1": {
    "sessions": [
      {
        "id": "session-id-1",
        "title": "默认会话",
        "createdAt": "2026-04-22T10:00:00.000Z",
        "updatedAt": "2026-04-22T10:00:00.000Z"
      }
    ]
  },
  "user2": {
    "sessions": []
  }
}
```

说明：

- 这里的 `id` 应与 Pi sessionId 对应
- 不要只相信前端传来的 sessionId
- 每次访问 session 前必须查这个映射

## 8. workspace 与 cwd 设计

这是多用户系统最关键的隔离点。

### 8.1 推荐方案

建议每个用户使用独立 workspace 目录。

示例：

```text
.next-pi-data/workspaces/
  user1/
    .pi/
      extensions/
      tilldown/
  user2/
    .pi/
      extensions/
      tilldown/
```

这样可以避免：

- 不同用户任务文件混在一起
- 不同用户写同一个 `.pi/tilldown` 目录
- 不同用户的 session 文件互相污染

### 8.2 插件复制策略

因为 Pi 扩展会从当前项目或 workspace 的 `.pi/extensions/` 加载，所以每个用户 workspace 中都应能访问 tilldown 插件。

可选方案：

#### 方案 A：初始化用户 workspace 时复制插件

创建用户 workspace 时，把当前项目的：

```text
.pi/extensions/tilldown/
```

复制到：

```text
.next-pi-data/workspaces/<userId>/.pi/extensions/tilldown/
```

优点：

- 隔离彻底
- 每个用户 workspace 自成一体

缺点：

- 插件更新时需要同步

#### 方案 B：共享同一份插件目录

让 Pi SDK 的资源加载器继续使用当前项目根目录作为 cwd。  
这种方案初期更简单，但多用户隔离较弱。

本期推荐使用方案 A。

### 8.3 cwd 选择

每个用户的 Pi session 应使用自己的 cwd：

```text
cwd = <projectRoot>/.next-pi-data/workspaces/<userId>
```

这样 tilldown 插件写出的任务文件会落在：

```text
.next-pi-data/workspaces/<userId>/.pi/tilldown/tasks.<sessionId>.json
```

这满足：

- 同用户多 session 隔离
- 不同用户隔离
- 不修改 tilldown 插件代码

## 9. Pi SDK 使用要求

### 9.1 服务端创建 session

服务端需要封装一个 Pi session 管理模块。

建议文件：

```text
src/lib/pi/runtime.ts
```

职责：

- 根据 `userId` 获取用户 workspace
- 根据 `sessionId` 打开或创建 Pi AgentSession
- 维护内存中的 runtime 缓存
- 提供发送消息的方法
- 提供创建新 session 的方法

### 9.2 是否使用 createAgentSessionRuntime

本系统有“多会话切换”和“创建新会话”的需求。  
因此推荐使用：

```text
createAgentSessionRuntime()
```

理由：

- 它适合管理当前活跃会话
- 支持 newSession
- 支持 switchSession
- 支持 fork 等扩展能力

如果开发人员一开始不熟悉，也可以先用 `createAgentSession()` 做单 session 通路。  
但最终多会话版本建议收敛到 runtime 管理。

### 9.3 runtime 缓存 key

服务端可以用内存 Map 缓存 runtime。

key 格式建议：

```text
<userId>:<sessionId>
```

注意：

- 这是本地开发和单进程部署可用的方案
- 多进程或 serverless 下不能依赖内存 Map
- 本期测试版允许使用内存 Map

## 10. API 设计

建议使用 Next.js Route Handlers。

所有 API 都必须：

1. 从 Cookie 中解析当前用户
2. 校验用户已登录
3. 校验 session 属于当前用户
4. 使用服务端 Pi SDK 执行操作

### 10.1 登录 API

路径建议：

```text
POST /api/auth/login
```

请求：

```json
{
  "username": "user1",
  "password": "123456"
}
```

成功响应：

```json
{
  "ok": true,
  "user": {
    "id": "user1",
    "name": "user1"
  }
}
```

行为：

- 校验写死账号
- 成功后设置 HTTP-only Cookie
- 失败返回 401

### 10.2 登出 API

路径建议：

```text
POST /api/auth/logout
```

行为：

- 清除登录 Cookie

### 10.3 当前用户 API

路径建议：

```text
GET /api/auth/me
```

行为：

- 返回当前登录用户
- 未登录返回 401

### 10.4 查询会话列表

路径建议：

```text
GET /api/sessions
```

响应：

```json
{
  "sessions": [
    {
      "id": "session-id-1",
      "title": "默认会话",
      "createdAt": "2026-04-22T10:00:00.000Z",
      "updatedAt": "2026-04-22T10:00:00.000Z"
    }
  ]
}
```

### 10.5 创建新会话

路径建议：

```text
POST /api/sessions
```

请求：

```json
{
  "title": "新会话"
}
```

行为：

- 为当前用户创建新的 Pi session
- 保存 session 映射
- 返回新 session

### 10.6 获取会话消息

路径建议：

```text
GET /api/sessions/:sessionId/messages
```

行为：

- 校验 session 属于当前用户
- 返回该 session 的历史消息

响应结构可根据 SDK 实际消息结构调整，但前端至少需要：

```json
{
  "messages": [
    {
      "id": "message-id",
      "role": "user",
      "content": "你好",
      "createdAt": "2026-04-22T10:00:00.000Z"
    }
  ]
}
```

### 10.7 发送消息

路径建议：

```text
POST /api/sessions/:sessionId/messages
```

请求：

```json
{
  "message": "帮我添加三个任务"
}
```

行为：

- 校验 session 属于当前用户
- 调用 Pi SDK 向该 session 发送消息
- 返回 AI 回复

本期可以先做非流式返回。  
如果实现流式，需要使用 SSE 或 ReadableStream。

### 10.8 启动 tilldown

路径建议：

```text
POST /api/sessions/:sessionId/tilldown/start
```

行为：

- 校验 session 属于当前用户
- 向该 Pi session 发送 `/tilldown`
- 返回启动结果

注意：

- 不要直接改任务 JSON 文件启动
- 应通过 Pi session 命令触发，让插件自己处理

### 10.9 停止 tilldown

路径建议：

```text
POST /api/sessions/:sessionId/tilldown/stop
```

行为：

- 校验 session 属于当前用户
- 向该 Pi session 发送 `/tilldown-stop`

### 10.10 查询任务列表

路径建议：

```text
GET /api/sessions/:sessionId/tasks
```

行为：

- 校验 session 属于当前用户
- 查询当前 session 对应的 tilldown 任务列表

实现方式有两个：

#### 方式 A：读取任务 JSON 文件

根据用户 workspace 和 sessionId 拼出文件路径：

```text
<workspace>/.pi/tilldown/tasks.<sessionId>.json
```

读取并返回。

优点：

- 简单
- 不消耗模型调用

缺点：

- 与插件内部文件命名规则有耦合

#### 方式 B：调用 todo_list 工具或发送命令

通过 Pi 工具或消息获取任务列表。

优点：

- 更符合插件封装

缺点：

- 实现复杂
- 可能触发模型流程，不适合作为普通 UI 高频刷新

本期推荐方式 A。

## 11. 前端组件设计

建议目录：

```text
src/app/
  login/
    page.tsx
  page.tsx

src/components/
  LoginForm.tsx
  AppShell.tsx
  SessionSidebar.tsx
  ChatPanel.tsx
  TaskPanel.tsx
```

### 11.1 `LoginForm`

职责：

- 输入用户名
- 输入密码
- 调用登录 API
- 登录成功后跳转主页面

### 11.2 `AppShell`

职责：

- 管理三栏布局
- 保存当前选中的 sessionId
- 协调左中右三个区域

### 11.3 `SessionSidebar`

职责：

- 拉取会话列表
- 显示会话列表
- 创建新会话
- 切换当前会话

### 11.4 `ChatPanel`

职责：

- 显示当前会话消息
- 输入消息
- 发送消息
- 显示 AI 回复
- 提供“开始 tilldown”按钮
- 提供“停止 tilldown”按钮

### 11.5 `TaskPanel`

职责：

- 拉取当前 session 的任务列表
- 显示任务状态
- 显示任务描述
- 显示统计信息
- 支持刷新
- 支持定时自动刷新

建议自动刷新间隔：

```text
1000ms - 3000ms
```

本期推荐：

```text
2000ms
```

## 12. 任务列表展示要求

右侧任务列表至少显示：

- 任务 ID
- 状态
- 描述
- retryCount / maxRetries
- result
- lastError

状态显示建议：

- `pending`：灰色
- `in_progress`：蓝色
- `done`：绿色
- `failed`：红色
- `cancelled`：黄色或灰色

如果任务列表为空，显示：

```text
当前会话暂无任务
```

## 13. tilldown 按钮行为

中间聊天区域需要提供按钮：

```text
开始 tilldown
```

点击后：

1. 调用 `POST /api/sessions/:sessionId/tilldown/start`
2. 后端向当前 Pi session 发送 `/tilldown`
3. 前端显示启动结果
4. 右侧任务列表继续自动刷新

也可以提供：

```text
停止 tilldown
```

点击后：

1. 调用 `POST /api/sessions/:sessionId/tilldown/stop`
2. 后端向当前 Pi session 发送 `/tilldown-stop`
3. 右侧任务列表刷新

## 14. 消息发送流程

用户在聊天框输入内容后：

1. 前端调用发送消息 API
2. 后端校验用户和 session 归属
3. 后端获取或创建对应 Pi AgentSession
4. 后端将消息发送给 Pi
5. Pi 模型可能调用 tilldown 工具
6. tilldown 插件将任务写入对应 session 的任务文件
7. 后端返回 AI 回复
8. 前端刷新消息区
9. 右侧任务区通过轮询刷新看到最新任务

## 15. 创建新会话流程

点击“新建会话”后：

1. 前端调用 `POST /api/sessions`
2. 后端从 Cookie 获取当前用户
3. 后端创建用户 workspace，如果不存在
4. 后端确保 tilldown 插件已复制到用户 workspace
5. 后端通过 Pi SDK 创建新 session
6. 后端保存 `userId -> sessionId` 映射
7. 返回新 session 信息
8. 前端把新 session 加入左侧列表
9. 自动切换到新 session

## 16. 切换会话流程

用户点击左侧某个会话：

1. 前端设置当前 sessionId
2. 中间聊天区加载该 session 消息
3. 右侧任务区加载该 session 任务文件
4. 所有后续操作都针对该 session

注意：

- 切换会话不能影响其他会话的运行状态
- 如果另一个会话正在 tilldown 自动执行，右侧切走后不应该停止它

## 17. 本地文件目录建议

建议项目运行时数据目录如下：

```text
.next-pi-data/
  auth/
    sessions.json
  users.json
  workspaces/
    user1/
      .pi/
        extensions/
          tilldown/
        tilldown/
          tasks.<sessionId>.json
    user2/
      .pi/
        extensions/
          tilldown/
        tilldown/
          tasks.<sessionId>.json
  agent/
    user1/
      auth.json
      models.json
      sessions/
    user2/
      auth.json
      models.json
      sessions/
```

说明：

- `workspaces/<userId>` 是 Pi 的 cwd
- `agent/<userId>` 是每个用户独立的 Pi agent 数据目录
- `users.json` 保存用户和 session 映射
- `auth/sessions.json` 保存网页登录态映射

## 18. 安全要求

虽然本期只是测试版，也必须满足基础安全要求：

- Cookie 必须是 HTTP-only
- API 不能相信前端传来的 userId
- API 必须从 Cookie 解析 userId
- API 必须校验 sessionId 归属当前用户
- 不允许读取任意文件路径
- 不允许前端传 taskFile 路径
- 不允许把服务端绝对路径直接暴露给前端

## 19. 并发要求

本期是本地测试版，可以先支持单进程 Node.js。

要求：

- 同一个 session 同一时间只允许一个消息请求执行
- 如果当前 session 正在执行，可以返回“当前会话正在处理中”
- 或者在服务端排队执行

建议先实现简单锁：

```text
Map<userId:sessionId, PromiseQueue>
```

说明：

- 该锁只适合本地开发和单进程部署
- 多实例部署时必须换成数据库锁或 Redis 锁

## 20. 部署建议

### 20.1 本期推荐部署方式

推荐：

- 本地开发
- 或自托管 Node.js
- 或 Docker 部署

不推荐本期直接部署到 Vercel Serverless。

原因：

- 当前 tilldown 插件写本地文件
- Vercel Serverless 的项目文件系统不适合做持久写入
- 内存 runtime 和锁在 serverless 下不稳定

### 20.2 如果未来要上 Vercel

需要改造：

- 任务存储改数据库
- session 映射改数据库
- runtime 管理改为可恢复
- 文件锁改数据库锁或 Redis 锁
- workspace 需要外部持久化方案

本期不做这些。

## 21. 错误处理要求

前端需要处理：

- 未登录
- 登录失败
- 会话不存在
- 无权限访问 session
- 消息发送失败
- tilldown 启动失败
- 任务文件不存在
- 任务文件损坏

后端 API 返回错误时建议统一结构：

```json
{
  "ok": false,
  "error": "错误说明"
}
```

成功时建议统一结构：

```json
{
  "ok": true,
  "data": {}
}
```

## 22. UI 交互要求

基础 UI 要求：

- 登录页清晰
- 三栏布局稳定
- 当前 session 高亮
- 发送消息时禁用发送按钮
- tilldown 启动时显示 loading
- 任务列表自动刷新
- API 错误需要展示给用户

不要求精美 UI，但要可用。

## 23. 推荐开发顺序

开发人员建议按以下顺序实现：

1. 创建 Next.js 基础项目结构
2. 实现写死账号登录
3. 实现 Cookie 登录态
4. 实现主页面三栏布局
5. 实现用户 workspace 初始化
6. 实现复制 tilldown 插件到用户 workspace
7. 实现 session 映射 JSON 存储
8. 实现创建新会话 API
9. 实现会话列表 API
10. 实现左侧会话列表 UI
11. 实现 Pi SDK session 创建与缓存
12. 实现发送消息 API
13. 实现中间聊天 UI
14. 实现 `/tilldown` 启动 API
15. 实现右侧任务列表 API
16. 实现右侧任务列表 UI 自动刷新
17. 实现 `/tilldown-stop`
18. 做完整联调

## 24. 验收标准

### 24.1 登录验收

- `user1 / 123456` 可以登录
- `user2 / 123456` 可以登录
- 错误账号不能登录
- 登录后刷新页面仍保持登录
- 登出后不能访问主页面

### 24.2 多用户隔离验收

- user1 创建的 session，user2 看不到
- user2 创建的 session，user1 看不到
- user1 不能通过 API 访问 user2 的 sessionId
- user2 不能通过 API 访问 user1 的任务列表

### 24.3 多 session 验收

- 同一用户可以创建多个 session
- 左侧能显示所有 session
- 点击不同 session 后，中间聊天内容切换
- 点击不同 session 后，右侧任务列表切换

### 24.4 聊天验收

- 可以在中间聊天框发送消息
- AI 可以返回响应
- 多轮对话在同一个 session 中连续
- 不同 session 的上下文互不污染

### 24.5 tilldown 验收

- 用户可以通过自然语言让 AI 添加任务
- 右侧任务列表能显示新增任务
- 点击“开始 tilldown”后能触发 `/tilldown`
- 当前任务状态会变成 `in_progress`
- 任务完成后状态会变成 `done`
- 任务失败后状态会变成 `failed`
- 一个任务失败后后续任务继续执行
- 所有任务完成后 runner 停止

### 24.6 动态刷新验收

- 右侧任务列表不需要刷新整个页面即可更新
- 切换 session 后任务列表显示正确
- tilldown 执行过程中可以看到状态变化

## 25. 推荐最小可用版本

如果开发时间有限，先完成以下最小版本：

- 写死两个账号登录
- 每个用户独立 workspace
- 左侧创建和切换 session
- 中间非流式聊天
- 右侧轮询任务 JSON 文件
- `/tilldown` 启动按钮

流式输出、任务编辑 UI、数据库持久化可以后续再做。

## 26. 一句话总结

本期要做的是一个 Next.js Web 壳：由 Next.js 负责登录、多用户隔离、session 管理和页面交互；由 Pi SDK 在服务端运行 Agent；由现有 `.pi/extensions/tilldown` 插件继续负责任务清单和自动执行。最终用户登录后，可以在左侧管理多个会话，在中间与 AI 对话，在右侧实时查看当前会话的任务列表，并通过按钮启动 tilldown 自动执行。
