# 只增加一个页面验证 extension 迁移灵活度：极简实施开发文档

## 1. 文档目标

本文档用于指导初级开发者完成一个**极简 POC 页面**，只验证一件事情：

- 现有 `.pi/extensions/tilldown` 插件，是否可以在 **Next.js 服务端通过 Pi SDK new session 的方式直接复用**

本次开发只做“跑通最小链路”，不做完整产品。

开发者阅读本文档后，应能直接开始开发，不需要再向需求方补问需求。

---

## 2. 本次只验证什么

本次只验证以下闭环：

1. 在 Next.js 服务端通过 Pi SDK 创建一个 session
2. 该 session 自动加载当前项目里的 `.pi/extensions/tilldown`
3. 页面可以向这个 session 发送一条普通消息
4. 页面可以向这个 session 发送 `/tilldown`
5. 页面可以读取当前 session 对应的任务文件  
   `.pi/tilldown/tasks.<sessionId>.json`
6. 页面能把结果展示出来

只要以上 6 点成立，就说明：

- 现有 extension 不需要重写
- 迁移到 SDK 用法是轻量的
- 插件与 session 的绑定逻辑是可复用的

---

## 3. 本次明确不做的内容

以下内容全部不做，避免把 POC 做复杂：

- 不做登录
- 不做多用户
- 不做用户隔离
- 不做数据库
- 不做 session 列表
- 不做会话切换
- 不做多页面
- 不做复杂 UI
- 不做流式输出
- 不做 SSE / WebSocket
- 不做任务编辑、删除、拖拽
- 不做生产级错误恢复
- 不做权限系统
- 不做 `createAgentSessionRuntime()`
- 不重写 `.pi/extensions/tilldown`

结论：**本次只做一个页面 + 一个服务端 session helper + 几个最小 API。**

---

## 4. 页面最终效果要求

页面只做一个，尽量朴素，不要求美观。

建议页面内容如下：

### 4.1 顶部区域

- 页面标题：`Pi SDK Extension Migration POC`
- 当前 `sessionId`
- 一个 `New Session` 按钮

### 4.2 中间操作区

- 一个文本输入框
- 一个 `Send Message` 按钮
- 一个 `Run /tilldown` 按钮
- 一个 `Refresh Tasks` 按钮

### 4.3 输出区

- 一个区域显示“最后一次 assistant 回复”
- 一个区域显示“当前任务文件 JSON”
- 一个区域显示“最近一次错误信息”，无错误时显示空

### 4.4 UI 原则

- 不做三栏布局
- 不做聊天气泡
- 不做复杂状态管理
- 不做组件拆分过度
- 可以全部放在一个页面里

只要清楚、能操作、能看结果即可。

---

## 5. 技术路线

本次采用最简单方案：

- 前端：Next.js App Router 页面
- 后端：Next.js Route Handlers
- Pi 接入方式：服务端 `createAgentSession()`
- 插件加载方式：让 Pi SDK 使用当前项目根目录作为 `cwd`
- 任务读取方式：直接读取 `.pi/tilldown/tasks.<sessionId>.json`

为什么这样做：

- `.pi/extensions/tilldown` 已经在当前项目中存在
- Pi SDK 会根据 `cwd` 自动发现 `.pi/extensions`
- 因此只要服务端创建 session 时 `cwd` 指向项目根目录，现有 extension 就会被加载

这正是本次需要验证的迁移灵活性。

---

## 6. 目录与文件建议

开发时建议新增以下文件：

```text
app/
  page.tsx
  api/
    demo/
      session/route.ts
      chat/route.ts
      tilldown/route.ts
      tasks/route.ts

src/
  lib/
    pi-demo.ts
```

说明：

- `app/page.tsx`：唯一页面
- `app/api/demo/session/route.ts`：新建 session
- `app/api/demo/chat/route.ts`：发送普通消息
- `app/api/demo/tilldown/route.ts`：发送 `/tilldown`
- `app/api/demo/tasks/route.ts`：读取当前 session 任务文件
- `src/lib/pi-demo.ts`：统一管理 demo session

---

## 7. 核心实现原则

### 7.1 Pi SDK 只能在服务端使用

必须遵守：

- 只能在服务端文件中 import `@mariozechner/pi-coding-agent`
- 不允许在 Client Component 中直接 import Pi SDK
- 所有 session 操作都必须在 Route Handler 或 server-only 模块中完成

因此：

- `src/lib/pi-demo.ts` 必须加 `import "server-only";`

### 7.2 使用单个当前 session 即可

本次不做多 session 管理，只维护一个“当前 demo session”。

可以使用模块级变量：

- `currentSession`
- `currentSessionId`

如果当前没有 session，则首次请求时自动创建。

### 7.3 不做复杂并发控制

本次页面只给一个人本地验证使用，可以先做最简单版本。

但仍建议增加一个极简保护：

- 当某次 `prompt()` 还未结束时，新的发送请求直接返回错误：`当前 session 正在处理中`

这样可以避免连续点击导致 session 状态混乱。

### 7.4 所有 API 返回统一结构

建议统一返回：

```json
{
  "ok": true,
  "data": {}
}
```

失败时：

```json
{
  "ok": false,
  "error": "错误信息"
}
```

---

## 8. Pi SDK 实现要求

### 8.1 使用 `createAgentSession()`

本次不要使用 `createAgentSessionRuntime()`。

原因：

- 本次只验证单 session 最小链路
- `createAgentSession()` 足够完成验证
- 可以显著降低开发复杂度

### 8.2 `cwd` 必须指向项目根目录

创建 session 时必须传入：

```ts
cwd: process.cwd()
```

这样 Pi SDK 才能自动发现：

```text
.pi/extensions/tilldown
```

### 8.3 使用 `SessionManager.create(process.cwd())`

建议使用持久化 session，而不是内存 session。

理由：

- 更容易看到真实 sessionId
- 更接近后续实际接入方式
- 有利于验证 extension 是否与 session 文件正常联动

### 8.4 如何判断 extension 已加载

本次不要求额外打印复杂日志。

验证方式直接看结果：

- 发送 `/tilldown` 后，若生成了  
  `.pi/tilldown/tasks.<sessionId>.json`
- 或者原有 tilldown 命令、工具开始工作

就可视为 extension 已成功参与运行。

---

## 9. 服务端模块设计

## 9.1 `src/lib/pi-demo.ts` 责任

这个文件负责：

- 创建 demo session
- 获取当前 demo session
- 保证同一时刻只执行一个 prompt
- 提供读取任务文件的方法
- 提供提取最后 assistant 文本的方法

建议导出的方法如下：

- `newDemoSession()`
- `getDemoSession()`
- `sendDemoMessage(message: string)`
- `runTilldown()`
- `readDemoTasks()`
- `getCurrentSessionId()`

### 9.2 建议的数据结构

可以使用模块级变量：

```ts
let currentSession: AgentSession | null = null;
let currentSessionId: string | null = null;
let currentRunning: Promise<unknown> | null = null;
```

### 9.3 并发保护逻辑

推荐规则：

- 若 `currentRunning` 不为空，说明当前正在执行 prompt
- 这时新请求直接抛错或返回失败
- 当前 prompt 执行结束后，将 `currentRunning` 置回 `null`

### 9.4 assistant 文本提取逻辑

`session.prompt()` 结束后，从 `session.state.messages` 中倒序找到最后一条 assistant 消息。

只提取其中 `type === "text"` 的内容拼接成字符串即可。

不需要实现复杂格式化。

---

## 10. API 设计

本次只做 4 个 API。

## 10.1 `POST /api/demo/session`

用途：

- 创建一个新的 demo session

执行逻辑：

1. 调用 `newDemoSession()`
2. 返回 `sessionId`

返回示例：

```json
{
  "ok": true,
  "data": {
    "sessionId": "xxx"
  }
}
```

---

## 10.2 `POST /api/demo/chat`

请求体：

```json
{
  "message": "请帮我创建 3 个任务"
}
```

用途：

- 给当前 session 发送一条普通消息

执行逻辑：

1. 校验 `message` 为非空字符串
2. 调用 `sendDemoMessage(message)`
3. 返回：
   - `sessionId`
   - `reply`

返回示例：

```json
{
  "ok": true,
  "data": {
    "sessionId": "xxx",
    "reply": "assistant 返回文本"
  }
}
```

---

## 10.3 `POST /api/demo/tilldown`

用途：

- 向当前 session 发送 `/tilldown`

执行逻辑：

1. 调用 `runTilldown()`
2. 返回：
   - `sessionId`
   - `reply`

说明：

- 这里本质上就是调用 `session.prompt("/tilldown")`
- 不要自己手动操作任务 JSON
- 必须通过 Pi session 触发插件命令

---

## 10.4 `GET /api/demo/tasks`

用途：

- 读取当前 session 对应的任务文件

执行逻辑：

1. 取当前 `sessionId`
2. 拼出路径：

```text
<project-root>/.pi/tilldown/tasks.<sessionId>.json
```

3. 如果文件不存在：
   - 返回 `tasks: null`
   - 不视为接口报错
4. 如果文件存在：
   - 解析 JSON
   - 原样返回

返回示例：

```json
{
  "ok": true,
  "data": {
    "sessionId": "xxx",
    "tasks": {
      "sessionId": "xxx",
      "tasks": []
    }
  }
}
```

---

## 11. 页面开发要求

## 11.1 页面职责

`app/page.tsx` 负责：

- 页面初始化时拿到一个 session
- 显示当前 sessionId
- 用户输入消息后调用 chat API
- 点击 `/tilldown` 后调用 tilldown API
- 点击刷新后调用 tasks API
- 把回复、任务 JSON、错误信息显示出来

## 11.2 页面状态建议

可使用以下 React state：

- `sessionId`
- `message`
- `reply`
- `tasksText`
- `error`
- `loading`

不需要引入额外状态库。

## 11.3 页面初始化逻辑

页面加载后自动请求一次：

```text
POST /api/demo/session
```

把返回的 `sessionId` 显示在页面上。

## 11.4 发送消息逻辑

点击 `Send Message`：

1. 清空错误状态
2. 调用 `POST /api/demo/chat`
3. 成功后更新：
   - `reply`
   - `sessionId`
4. 可选：再自动调用一次 `GET /api/demo/tasks`

## 11.5 启动 tilldown 逻辑

点击 `Run /tilldown`：

1. 清空错误状态
2. 调用 `POST /api/demo/tilldown`
3. 成功后更新：
   - `reply`
4. 然后自动调用 `GET /api/demo/tasks`

## 11.6 刷新任务逻辑

点击 `Refresh Tasks`：

1. 调用 `GET /api/demo/tasks`
2. 若有 JSON，则格式化展示
3. 若为空，则显示 `No task file yet`

## 11.7 显示要求

- `reply` 用 `pre` 或普通块展示即可
- `tasks` 必须用 `JSON.stringify(data, null, 2)` 格式化
- `error` 用红字显示即可

---

## 12. 推荐开发顺序

开发顺序必须按下面来，避免前端先写太多却没有后端可联调。

### 第一步：先完成 `src/lib/pi-demo.ts`

先确保以下能力存在：

- 能 new 一个 session
- 能拿到 `sessionId`
- 能发送普通消息
- 能发送 `/tilldown`
- 能读取任务文件

建议先在代码里把方法写完，再做 API。

### 第二步：完成 4 个 API

先让接口可单独联通：

- `POST /api/demo/session`
- `POST /api/demo/chat`
- `POST /api/demo/tilldown`
- `GET /api/demo/tasks`

### 第三步：完成最小页面

页面只做基本调用，不要一开始做样式优化。

### 第四步：手动联调验证

按以下顺序测试：

1. 创建 session
2. 发送普通消息
3. 让 agent 帮你创建几个任务
4. 发送 `/tilldown`
5. 刷新任务 JSON

### 第五步：补充错误处理

至少补以下错误展示：

- message 为空
- 当前 session 正在处理中
- 任务文件不存在
- Pi 调用抛错

---

## 13. 关键实现细节

## 13.1 Route Handler 必须使用 Node.js runtime

每个 API 文件都加：

```ts
export const runtime = "nodejs";
```

原因：

- Pi SDK 依赖 Node.js 能力
- tilldown extension 依赖本地文件系统

## 13.2 不允许浏览器直接读 `.pi`

必须通过服务端 API 读取任务文件，再返回给前端。

前端不允许直接访问：

```text
.pi/tilldown/tasks.<sessionId>.json
```

## 13.3 不要自己构造假的 task 数据

任务区展示的数据必须来自真实文件。

本次验证目标就是证明 extension 与 session 运行后，任务文件仍可正常产出与读取。

## 13.4 不要自己模拟 `/tilldown`

必须调用：

```ts
session.prompt("/tilldown")
```

不要直接调用 store，不要绕过插件命令。

## 13.5 任务文件不存在不算失败

在以下情况下，任务文件可能还不存在：

- 还没创建任何任务
- 还没执行相关命令
- 当前 session 尚未触发 tilldown 文件初始化

因此：

- 接口应正常返回
- 页面显示 `No task file yet`

---

## 14. 可参考的伪代码

以下是开发思路伪代码，不要求完全照抄，但逻辑应一致。

### 14.1 `src/lib/pi-demo.ts`

```ts
import "server-only";
import { createAgentSession, SessionManager } from "@mariozechner/pi-coding-agent";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

let currentSession = null;
let currentRunning = null;

export async function newDemoSession() {
  const { session } = await createAgentSession({
    cwd: process.cwd(),
    sessionManager: SessionManager.create(process.cwd()),
  });
  currentSession = session;
  return session;
}

export async function getDemoSession() {
  if (!currentSession) {
    currentSession = await newDemoSession();
  }
  return currentSession;
}

async function runExclusive(task) {
  if (currentRunning) {
    throw new Error("当前 session 正在处理中");
  }
  currentRunning = task();
  try {
    return await currentRunning;
  } finally {
    currentRunning = null;
  }
}

export async function sendDemoMessage(message: string) {
  const session = await getDemoSession();
  return runExclusive(async () => {
    await session.prompt(message);
    return {
      sessionId: session.sessionId,
      reply: extractLastAssistantText(session),
    };
  });
}

export async function runTilldown() {
  const session = await getDemoSession();
  return runExclusive(async () => {
    await session.prompt("/tilldown");
    return {
      sessionId: session.sessionId,
      reply: extractLastAssistantText(session),
    };
  });
}

export function readDemoTasks() {
  if (!currentSession) {
    return { sessionId: null, tasks: null };
  }
  const file = join(process.cwd(), ".pi", "tilldown", `tasks.${currentSession.sessionId}.json`);
  if (!existsSync(file)) {
    return { sessionId: currentSession.sessionId, tasks: null };
  }
  const tasks = JSON.parse(readFileSync(file, "utf8"));
  return { sessionId: currentSession.sessionId, tasks };
}
```

### 14.2 `app/api/demo/chat/route.ts`

```ts
export const runtime = "nodejs";

export async function POST(req: Request) {
  const body = await req.json();
  const message = typeof body.message === "string" ? body.message.trim() : "";

  if (!message) {
    return Response.json({ ok: false, error: "message 不能为空" }, { status: 400 });
  }

  try {
    const result = await sendDemoMessage(message);
    return Response.json({ ok: true, data: result });
  } catch (error) {
    return Response.json({ ok: false, error: getErrorMessage(error) }, { status: 500 });
  }
}
```

### 14.3 `app/page.tsx`

```tsx
"use client";

import { useEffect, useState } from "react";

export default function Page() {
  const [sessionId, setSessionId] = useState("");
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("");
  const [tasksText, setTasksText] = useState("No task file yet");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    void createSession();
  }, []);

  async function createSession() {}
  async function sendMessage() {}
  async function runTilldown() {}
  async function refreshTasks() {}

  return <main>...</main>;
}
```

---

## 15. 验收标准

开发完成后，必须满足以下验收标准。

### 15.1 session 创建成功

- 打开页面后能自动创建一个 session
- 页面能显示真实 `sessionId`

### 15.2 普通消息可用

- 输入普通文本后，能调用服务端 Pi session
- 页面能展示 assistant 回复

### 15.3 tilldown 命令可用

- 点击 `Run /tilldown` 后，后端实际执行 `session.prompt("/tilldown")`

### 15.4 任务文件可读取

- 当任务文件存在时，页面能读到真实 JSON
- 文件路径必须对应当前 sessionId

### 15.5 证明 extension 已复用

以下事实能够同时成立：

- Next.js 服务端通过 SDK 创建 session
- 没有重写现有 tilldown extension
- 当前 extension 仍然工作
- 任务文件仍然按 sessionId 输出

则视为本次目标达成。

---

## 16. 手动测试步骤

开发者完成后，按下面步骤自测。

### 场景一：创建 session

1. 启动 Next.js 项目
2. 打开页面
3. 确认页面显示一个 `sessionId`

### 场景二：发送普通消息

1. 输入：`请记住我们正在验证 tilldown extension 的 SDK 接入`
2. 点击 `Send Message`
3. 确认页面出现 assistant 回复

### 场景三：创建任务

1. 输入：`请帮我创建 3 个简单任务，并使用 tilldown 管理`
2. 点击 `Send Message`
3. 点击 `Refresh Tasks`
4. 查看是否出现任务 JSON

### 场景四：执行 tilldown

1. 点击 `Run /tilldown`
2. 等待返回
3. 点击 `Refresh Tasks`
4. 查看任务状态是否发生变化

---

## 17. 常见错误与处理方式

### 17.1 报错：Pi SDK 不能在浏览器端运行

原因：

- 把 Pi SDK import 到了 Client Component

处理：

- 只在服务端模块中 import
- 前端通过 API 调用

### 17.2 报错：任务文件不存在

原因：

- 当前 session 还没有触发 tilldown 相关流程

处理：

- 不要报错
- 页面显示 `No task file yet`

### 17.3 报错：当前 session 正在处理中

原因：

- 用户重复点击按钮，两个 `prompt()` 重叠执行

处理：

- 接口返回清晰错误
- 前端按钮在 loading 时禁用

### 17.4 报错：extension 没有效果

排查顺序：

1. 确认 `cwd` 是 `process.cwd()`
2. 确认项目根目录下存在 `.pi/extensions/tilldown`
3. 确认调用的是 `session.prompt("/tilldown")`
4. 确认不是自己手动伪造任务数据

---

## 18. 最终交付物要求

开发完成后，交付物必须包括：

- 一个可打开的 Next.js 页面
- 一个能创建 session 的最小后端实现
- 一个能发送普通消息的 API
- 一个能触发 `/tilldown` 的 API
- 一个能读取任务文件的 API
- 页面上能看到：
  - 当前 sessionId
  - 最后一次回复
  - 当前任务 JSON

不要求交付：

- 登录系统
- 多用户
- 完整聊天系统
- 完整任务管理系统

---

## 19. 一句话总结给开发者

你本次不是在做产品，而是在做一个**极简验证页面**。  
只要你证明“Next.js 服务端通过 Pi SDK 新建 session 后，可以直接复用当前 `.pi/extensions/tilldown` 并成功读到对应任务文件”，这次任务就算完成。
